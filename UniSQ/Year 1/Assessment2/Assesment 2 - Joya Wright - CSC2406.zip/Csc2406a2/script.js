
//declaring variable for tracking visitors on the site
var personNumber;
function initialize(){
    personNumber = 0;
    updateCounter();

    $("p1yes").on("click, counterButton");
}

function counterButton(event) {
    ++personNumber;
    updateCounter();
}

// creating the hideall function which will hide all parts of the questionnaire from 2-4 upon the loading of the site
$("maindiv").on("pageshow",hideall)

    function hideall(event){
    $(".part2div").hide();
    $(".part3div").hide();
    $(".part3div").hide();

};
// creating a function that hides part 1 and displays part 2 simletanously. This should occur when the user selects the 'NO' button in part 1
$(".p1nobutton").on('click', navtopart2)

function navtopart2(event){ 
    $(".part1div").hide();
    $(".part2div").show();
};
$(".part2div").hide();

//creating a function that hides part 2 and displays part 3 simletanously. This should occur when the user selects 'NEXT'
$(".p2nextbutton").on('click', navtopart3)

function navtopart3(event){ 
    $(".part2div").hide();
    $(".part3div").show();
};
$(".part3div").hide();

//creating a function that hides part 3 and displays part 4 simletanously. This should occur when the user selects 'NEXT'
$(".p3nextbutton").on('click', navtopart4)

function navtopart4(event){ 
    $(".part3div").hide();
    $(".part4div").show();
};
$(".part4div").hide();

// function that skips part 3 if person has no pets to add
$(".p3no").on('change', skippart3)

function skippart3(event){ 
    $(".part3div").hide();
    $(".part4div").show();
};
$(".part4div").hide();


//putting the createPerson function into action when the "yes" button is clicked when user asked if they need to add another person and adding the number of person to the tracking variable
$("#p1yes").on("click", createPerson());
++personNumber;
//creating a function that reveals additional fields to enter person details if required
function createPerson(personNumber){
    const newPerson = document.getElementById("newPersonTemplate").content.cloneNode(true);
    newPerson.getElementById("givenname").setAttribute("id", "name" + personNumber);
    newPerson.getElementById("givenname").setAttribute("name", "givennamefield" + personNumber);
    newPerson.getElementById("surname").setAttribute("id", "name" + personNumber);
    newPerson.getElementById("surname").setAttribute("name", "surnamefield" + personNumber);
    newPerson.getElementById("dob").setAttribute("id", "name" + personNumber);
    newPerson.getElementById("dob").setAttribute("name", "dobfield" + personNumber);
    newPerson.getElementById("cob").setAttribute("id", "name" + personNumber);
    newPerson.getElementById("cob").setAttribute("name", "cobfield" + personNumber);
    newPerson.getElementById("gender").setAttribute("id", "name" + personNumber);
    newPerson.getElementById("gender").setAttribute("name", "genderfield" + personNumber);
    //updating 'for' attribute in the labels
    newPerson.getElementById("givennamefield").setAttribute("id", "givennamefield" + personNumber);
    newPerson.getElementById("surnamefield").setAttribute("id", "surnamefield" + personNumber);
    newPerson.getElementById("dobfield").setAttribute("id", "dobfield" + personNumber);
    newPerson.getElementById("cobfield").setAttribute("id", "cobfield" + personNumber);
    newPerson.getElementById("genderfield").setAttribute("id", "genderfield" + personNumber);
    //adding the new people at the end of the new person section
    $("#newPersonTemplate").prepend(newPerson);
}

// function that toggles the help option
$(".help").on('click', showManual)

function showManual(event){ 
    $(".helpinfo").show();
};
$(".helpinfo").hide();

